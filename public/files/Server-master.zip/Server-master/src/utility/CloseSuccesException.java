package utility;

/**
 *
 * @author simon
 */
public class CloseSuccesException extends RuntimeException {

    public CloseSuccesException(String message) {
        super(message);
    }

}
