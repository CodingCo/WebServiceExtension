#! bin/bash
java -cp dist/ServerSide.jar chatserver.ServerExecutor
